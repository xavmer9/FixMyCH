angular.module('citizen-engagement')
  .constant('apiUrl', '/api-proxy')
;

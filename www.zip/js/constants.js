angular.module('citizen-engagement')
  .constant('apiUrl', '/api-proxy')
  .constant('mapboxSecret', 'pk.eyJ1IjoieGF2bWVyOSIsImEiOiJjajBnc2kyZjQwMDNyMzNtamRnd2s0ODY3In0.APe3Zw3FtLEh5sHsH4uJhw')
;

angular.module('citizen-engagement').factory('IssueService', function($http, apiUrl) {
  var service = {};

  //Get all issues
  service.getIssues = function(page, items) {
    page = page || 1; // Start from page 1
    items = items || [];
    // GET the current page
    return $http({
      method: 'GET',
      url: apiUrl + '/issues',
      params: {
        page: page
      }
    }).then(function(res) {
      if (res.data.length) {
        // If there are any items, add them
        // and recursively fetch the next page
        items = items.concat(res.data);
        return service.getIssues(page + 1, items);
      }
      return items;
    });
  };

  //Get issues from a LatLng by location
  service.getIssuesByLocation = function(map, page, items) {
    page = page || 1; // Start from page 1
    var bounds = map.getBounds();
    items = items || [];
    // POST method
    return $http({
      method: 'POST',
      url: apiUrl + '/issues/searches',
      params: {
        page: page,
        pageSize: 50
      },
      data: {
        location: {
          '$geoWithin': {
           '$geometry': {
             type: 'Polygon',
             coordinates: [ [ [ bounds.getSouthWest().lng, bounds.getSouthWest().lat ],
                              [ bounds.getNorthWest().lng, bounds.getNorthWest().lat ],
                              [ bounds.getNorthEast().lng, bounds.getNorthEast().lat ],
                              [ bounds.getSouthEast().lng, bounds.getSouthEast().lat ],
                              [ bounds.getSouthWest().lng, bounds.getSouthWest().lat ]
                          ] ]
           }
          }
        }
      }
    }).then(function(res) {
      if (res.data.length) {
        // If there are any items, add them
        // and recursively fetch the next page
        items = items.concat(res.data);
        return service.getIssuesByLocation(map, page + 1, items);
      }
      return items;
    });
  };

  service.getMyIssues = function() {
    // GET me/issues
    return $http({
      method: 'GET',
      url: apiUrl + '/me/issues',
    }).then(function(res) {
      console.log(res);
      return res;
    });
  };


  return service;

});

angular.module('citizen-engagement').controller('IssuesCtrl', function(IssueService) {
  var issueCtrl = this;

  IssueService.getIssues().then(function(issues) {
    //console.log(issues);
    issueCtrl.issues = issues;
  });

  issueCtrl.toggleOrder = function(){
    console.log('wopla');
  };

  IssueService.getMyIssues().then(function(issues) {
    console.log(issues);
  })








});
